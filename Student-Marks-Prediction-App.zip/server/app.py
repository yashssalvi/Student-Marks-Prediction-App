from flask import Flask
from flask import request
import pymysql
import pandas as pd
import json
import joblib
import numpy as np

app = Flask(__name__)

app.secret_key = 'any random string'

UPLOAD_FOLDER = 'static/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="studentmarks")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

SVC_Regressor_model = joblib.load("models/SVC_Regressor_model.joblib")

"########################################################################################"     

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        fname = request_data['fname']
        mob = request_data['mob']
        email = request_data['email']
        password = request_data['password']
        department = request_data['department']
        
        cursor.execute('SELECT * FROM register WHERE email = %s', (email))
        count = cursor.rowcount
        if count == 0: 
            sql1 = "INSERT INTO register(fname, phone,email, password, department) VALUES (%s, %s, %s, %s, %s);"
            val1 = (fname, mob,email, password, department)
            cursor.execute(sql1,val1)
            con.commit()    
            
            return "success" 
        else:               
            return "fail"   

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        fname = request_data['fname']
        password = request_data['pass']
        
        cursor.execute('SELECT * FROM register WHERE email = %s AND password = %s', (fname, password))
        count = cursor.rowcount
        print(count)
        if count > 0:
            row = cursor.fetchone() 
            
            jsonObj = json.dumps(row)
            print(jsonObj)
            
            return jsonObj
        else:
            return "fail"
        
@app.route('/teacherlogin', methods=['GET', 'POST'])
def teacherlogin():
    if request.method == "POST":
        
        #getting the response data
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        fname = request_data['fname']
        password = request_data['pass']
        
        cursor.execute('SELECT * FROM teachers WHERE email = %s AND password = %s', (fname, password))
        count = cursor.rowcount
        print(count)
        if count > 0:
            row = cursor.fetchone() 
            
            jsonObj = json.dumps(row)
            print(jsonObj)
            
            return jsonObj
        else:
            return "fail"
        
@app.route('/getAllSem/<dept>', methods=['GET', 'POST'])
def getAllSem(dept):
        
    cursor.execute('SELECT DISTINCT sem FROM questionary WHERE dept=%s',(dept))
    row = cursor.fetchall() 
    single_list = [item for sublist in row for item in sublist]
    
    jsonObj = json.dumps(single_list)
    
    return jsonObj

@app.route('/getAllClass/<dept>/<sem>', methods=['GET', 'POST'])
def getAllClass(dept,sem):
        
    cursor.execute('SELECT DISTINCT class FROM questionary WHERE dept=%s AND sem=%s',(dept,sem))
    row = cursor.fetchall() 
    single_list = [item for sublist in row for item in sublist]
    
    jsonObj = json.dumps(single_list)
    
    return jsonObj

@app.route('/getAllSubject/<dept>/<sem>/<classes>', methods=['GET', 'POST'])
def getAllSubject(dept,sem,classes):
        
    cursor.execute('SELECT DISTINCT subject FROM questionary WHERE dept=%s AND sem=%s AND class=%s',(dept,sem,classes))
    row = cursor.fetchall() 
    single_list = [item for sublist in row for item in sublist]
    
    jsonObj = json.dumps(single_list)
    
    return jsonObj

@app.route('/getQuestions/<dept>/<sem>/<classes>/<subject>', methods=['GET', 'POST'])
def getQuestions(dept,sem,classes,subject):
        
    cursor.execute('SELECT * FROM questionary WHERE dept=%s AND sem=%s AND class=%s AND subject=%s',(dept,sem,classes,subject))
    row = cursor.fetchall() 
    
    jsonObj = json.dumps(row)
    
    return jsonObj

@app.route('/getAllTeachers', methods=['GET', 'POST'])
def getAllTeachers():
        
    cursor.execute('SELECT name FROM teachers')
    row = cursor.fetchall() 
    single_list = [item for sublist in row for item in sublist]
    
    jsonObj = json.dumps(single_list)
    
    return jsonObj

@app.route('/checkScore', methods=['GET', 'POST'])
def checkScore():
    if request.method == 'POST':
        
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        sname = request_data['sname']
        email = request_data['email']
        dept = request_data['dept']
        classof = request_data['class']
        subject = request_data['subject']
         
        cursor.execute('SELECT * FROM allscore WHERE studentname = %s AND email = %s AND dept = %s AND class = %s AND subject = %s', (sname,email,dept,classof,subject))
        count = cursor.rowcount
        print(count)
        if count > 0:
            return "success"
        else:
            return "fail"

@app.route('/submitScore', methods=['GET', 'POST'])
def submitScore():
    if request.method == 'POST':
        
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        sname = request_data['sname']
        email = request_data['email']
        dept = request_data['dept']
        classof = request_data['class']
        subject = request_data['subject']
        teacher = request_data['teacher']
        score = request_data['score']
        stuid = request_data['stuid']
         
        sql1 = "INSERT INTO allscore(studentname,email,dept,class,subject,teacher,ct1,ct2,viva1,viva2,quescore,result,studid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
        val1 = (sname,email,dept,classof,subject,teacher,"-","-","-","-",score,"None",stuid)
        cursor.execute(sql1,val1)
        con.commit()    
        
        return "success"    
    
@app.route('/getAllClassforTeacher/<dept>', methods=['GET', 'POST'])
def getAllClassforTeacher(dept):
        
    cursor.execute('SELECT DISTINCT class FROM questionary WHERE dept=%s',(dept))
    row = cursor.fetchall() 
    single_list = [item for sublist in row for item in sublist]
    
    jsonObj = json.dumps(single_list)
    
    return jsonObj

@app.route('/checkAllScore', methods=['GET', 'POST'])
def checkAllScore():
    if request.method == 'POST':
        
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        teachername = request_data['teachername']
        dept = request_data['dept']
        classof = request_data['class']
         
        cursor.execute('SELECT * FROM allscore WHERE teacher = %s AND dept = %s AND class = %s', (teachername,dept,classof))
        count = cursor.rowcount
        print(count)
        if count > 0:
            return "success"
        else:
            return "fail"
        
@app.route('/getAllStudentData/<teachername>/<dept>/<classof>', methods=['GET', 'POST'])
def getAllStudentData(teachername,dept,classof):
        
    cursor.execute('SELECT * FROM allscore WHERE teacher = %s AND dept = %s AND class = %s', (teachername,dept,classof))
    rows = cursor.fetchall() 
    
    column_names = [desc[0] for desc in cursor.description]
    
    # Convert rows to list of dictionaries
    data = []
    for row in rows:
        data.append(dict(zip(column_names, row)))
    
    # Convert data to JSON format
    jsonObj = json.dumps(data)
    
    return jsonObj

@app.route('/predictData', methods=['GET', 'POST'])
def predictData():
    if request.method == 'POST':
        
        request_data = request.data 
        #converting it from json to key value pair
        request_data = json.loads(request_data.decode('utf-8'))
        
        data = request_data['data']
        found_hyphen = False
        
        for item in data:
            if "-" in item.values() or "" in item.values():
                found_hyphen = True
                break
        
        if found_hyphen:
            return "fail"
        else:            
            encoded_df = pd.DataFrame(data)
            var2=encoded_df[["ct1","ct2","viva1","viva2","quescore"]]   
            var2 = var2.rename(columns={'quescore': 'questionary'})
            new_predictions = SVC_Regressor_model.predict(var2)  
            predicted_results = np.array(new_predictions)
            rounded_results = np.round(predicted_results)
            rounded_results_int = rounded_results.astype(int)
            
            encoded_df['result'] = rounded_results_int            
            df_dict = encoded_df.to_dict(orient='records')
            
            for dictdata in df_dict:  
                sql2 = "UPDATE allscore SET ct1=%s,ct2=%s,viva1=%s,viva2=%s,result=%s WHERE id = %s"
                val2 = (dictdata["ct1"], dictdata["ct2"], dictdata["viva1"], dictdata["viva2"], dictdata["result"], dictdata["id"])
                cursor.execute(sql2,val2)
                con.commit()
                
            jsonObj = json.dumps(df_dict)            
            return jsonObj
        
@app.route('/getStudentResult/<name>/<email>', methods=['GET', 'POST'])
def getStudentResult(name,email):
        
    cursor.execute('SELECT * FROM allscore WHERE studentname = %s AND email = %s', (name,email))
    rows = cursor.fetchall() 
    
    column_names = [desc[0] for desc in cursor.description]
    
    # Convert rows to list of dictionaries
    data = []
    for row in rows:
        data.append(dict(zip(column_names, row)))
    
    # Convert data to JSON format
    jsonObj = json.dumps(data)
    
    return jsonObj
    
if __name__ == "__main__":
    app.run("0.0.0.0")
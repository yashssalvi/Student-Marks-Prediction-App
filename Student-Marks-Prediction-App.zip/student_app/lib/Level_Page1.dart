import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:student_app/server.dart';
import 'MCQ.dart';
import 'ViewData.dart';
import 'login.dart';
import 'my-globals.dart';

class LevelPage1 extends StatefulWidget {
  @override
  _LevelPageState1 createState() => _LevelPageState1();
}

class _LevelPageState1 extends State<LevelPage1> {

  String selectedDepartment = 'Select department';
  String selectedClass = 'Select class';

  var departments = [
    'Select department',
    'Computer Engineering',
    'Information Technology',
    'Electronics and Telecommunication',
  ];

  var classs = [
    'Select class',
  ];

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: new AppBar(
        title: new Text("Teacher Home"),
        elevation:defaultTargetPlatform==TargetPlatform.android ? 5.0 : 0.0 ,
      ),
      drawer: new Drawer(
        child: new ListView(
          children: [
            new UserAccountsDrawerHeader(
              accountName: new Text(trglobalFname),
              accountEmail: new Text(trglobalHeaderEmail),
              currentAccountPicture: new CircleAvatar(
                backgroundColor:
                Theme.of(context).platform==TargetPlatform. iOS
                    ? Colors.deepPurple
                    :Colors.white,
                child: new Text(trglobalFname.split(" ")[0][0].toUpperCase()+trglobalFname.split(" ")[1][0].toUpperCase()),
                // child: new Text("UN"),
              ),
            ),
            new ListTile(
              title: new Text("Home"),
              trailing: new Icon(Icons.home),
              onTap: (){
                Navigator.of(context).pop();
              },
            ),
            new ListTile(
                title: new Text("logout"),
                trailing: new Icon(Icons.logout),
                onTap: ()=> Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LoginPage()))
            ),
          ],
        ),
      ),
      body:SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Select details for result', style: TextStyle(color: Colors.black, fontSize: 23.0, fontWeight: FontWeight.bold),),
                ],
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedDepartment,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: departments.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: Text(item),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    CharacterApi.getClass(newValue!).then((response) {
                      setState(() {
                        Iterable list = json.decode(response.body);
                        classs.clear();
                        selectedClass = 'Select class';
                        classs.add('Select class');
                        classs.addAll(list.map((semester) => semester.toString()));
                      });
                    });
                    selectedDepartment = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedClass,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: classs.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: Text(item),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    selectedClass = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              MaterialButton(
                onPressed: () async {
                  String text1,text3;

                  text1 = selectedDepartment;
                  text3 = selectedClass;

                  if(text1 == 'Select department' || text3 == 'Select class')
                  {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Text Field is empty, Please Fill All Data"),
                    ));
                  }
                  else{
                    final url = serverurl+"checkAllScore";
                    final response = await http.post(Uri.parse(url), body: json.encode({'teachername' : trglobalFname,'dept' : text1,'class' : text3}));
                    String responseBody = response.body;
                    if(responseBody == "success"){
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>ViewData(text1,text3)));
                    }
                    else{
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("No data found !"),
                      ));
                    }
                  }
                },
                height: 55,
                color: Colors.deepPurple,
                child: Text("Submit", style: TextStyle(color: Colors.white, fontSize: 16.0),),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CharacterApi {
  static Future getClass(dept) {
    return http.get(Uri.parse(serverurl+"getAllClassforTeacher/"+dept));
  }
}


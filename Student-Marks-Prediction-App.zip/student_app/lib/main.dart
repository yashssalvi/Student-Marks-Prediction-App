import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'login.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme:  new ThemeData(primarySwatch: Colors.deepPurple,
            primaryColor: defaultTargetPlatform==TargetPlatform.iOS
                ? Colors.grey[50]
                :null),
        home:new LoginPage(),
        routes: <String,WidgetBuilder>{
          '/login': (context) =>LoginPage(),
          // '/register': (context) => register(),
          // "/b":(BuildContext context)=> new Level_Page("second  page"),
          // "/c":(BuildContext context)=> new Level_Page("third   page"),
        });
  }
}

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:http/http.dart' as http;
import 'package:student_app/teacherlogin.dart';
import 'package:student_app/register.dart';
import 'package:student_app/server.dart';
import 'Level_Page.dart';
import 'my-globals.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({ Key? key }) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  var Fname = TextEditingController(text: "yashsalvi1999@gmail.com");
  var pass = TextEditingController(text: "yash");
  int activeIndex = 0;
  List characterList = [];

  @override
  void initState() {
    Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        activeIndex++;
        if (activeIndex == 4)
          activeIndex = 0;
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(height: 30,),
              Container(
                height: 300,
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedOpacity(
                        opacity: activeIndex == 0 ? 1 : 0, 
                        duration: Duration(seconds: 1,),
                        curve: Curves.linear,
                        child: Image.asset('assets/img/login.png', height: 400,),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedOpacity(
                        opacity: activeIndex == 1 ? 1 : 0, 
                        duration: Duration(seconds: 1),
                        curve: Curves.linear,
                        child: Image.asset('assets/img/signup.png', height: 400,),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedOpacity(
                        opacity: activeIndex == 2 ? 1 : 0,
                        duration: Duration(seconds: 1),
                        curve: Curves.linear,
                        child: Image.asset('assets/img/ab.png', height: 400,),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedOpacity(
                        opacity: activeIndex == 3 ? 1 : 0,
                        duration: Duration(seconds: 1),
                        curve: Curves.linear,
                        child: Image.asset('assets/img/bc.png', height: 400,),
                      ),
                    ),
                  ]
                ),
              ),
              SizedBox(height: 30,),
              TextField(
                controller: Fname,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                  labelText: 'Email',
                  hintText: 'Enter email id',
                  labelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 17.0,
                    fontWeight: FontWeight.w400,
                  ),
                  hintStyle: TextStyle(
                    color: Colors.grey,
                    fontSize: 17.0,
                  ),
                  prefixIcon: Icon(Iconsax.user, color: Colors.black, size: 18, ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  floatingLabelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
              ),
              SizedBox(height: 15,),
              TextField(
                controller: pass,
                obscureText: true, // This will hide the password input
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                  labelText: 'Password',
                  hintText: 'Enter password',
                  hintStyle: TextStyle(
                    color: Colors.grey,
                    fontSize: 17.0,
                  ),
                  labelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 17.0,
                    fontWeight: FontWeight.w400,
                  ),
                  prefixIcon: Icon(Iconsax.key, color: Colors.black, size: 18, ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  floatingLabelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {}, 
                    child: Text('Forgot Password?', style: TextStyle(color: Colors.black, fontSize: 16.0, fontWeight: FontWeight.bold),),
                  )
                ],
              ),
              SizedBox(height: 10,),
              MaterialButton(
                onPressed: () async {
                  String text1,text2;

                  text1 = Fname.text ;
                  text2 = pass.text ;
                  if(text1 == '' || text2 == '')
                  {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Text Field is empty, Please Fill All Data"),
                    ));
                  }
                  else{
                  //url to send the post request to
                    final url = serverurl+"login";
                    final response = await http.post(Uri.parse(url), body: json.encode({'fname' : text1,'pass' : text2}));
                    String responseBody = response.body;

                    if(responseBody != "fail"){
                      Iterable list = json.decode(response.body);
                      characterList.clear();
                      characterList.addAll(list) ;
                      print(list);
                      globalFname= characterList[1];
                      globalHeaderEmail= characterList[3];
                      globalHeaderDept= characterList[5];
                      Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => LevelPage()));

                    }
                    else{
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Invalid username and Password!"),
                      ));
                    }
                  }
                },
                height: 55,
                color: Colors.deepPurple,
                child: Text("Sign In", style: TextStyle(color: Colors.white, fontSize: 16.0),),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Don\'t have an account?', style: TextStyle(color: Colors.grey.shade600, fontSize: 18.0, fontWeight: FontWeight.bold),),
                  TextButton(
                    onPressed: () {
                      // Navigator.of(context).pop();
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>register()));
                    },
                    child: Text('Sign Up', style: TextStyle(color: Colors.deepPurple, fontSize: 18.0, fontWeight: FontWeight.bold),),
                  )
                ],
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>TeacherLoginPage()));
                },
                child: Text('Teacher Sign In', style: TextStyle(color: Colors.deepPurple, fontSize: 18.0, fontWeight: FontWeight.bold),),
              )
            ],
          ),
        ),
      )
    );
  }

  void goToRegisterScreen() {
    Navigator.pushReplacementNamed(context, "/register");
  }
}

import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:student_app/StudentResult.dart';
import 'package:student_app/server.dart';
import 'MCQ.dart';
import 'login.dart';
import 'my-globals.dart';

class LevelPage extends StatefulWidget {
  @override
  _LevelPageState createState() => _LevelPageState();
}

class _LevelPageState extends State<LevelPage> {

  String selectedDepartment = 'Select department';
  String selectedSem = 'Select semester';
  String selectedClass = 'Select class';
  String selectedSubject = 'Select subject';
  String selectedTeacher = 'Select teacher';

  var userid = TextEditingController();

  var departments = [
    'Select department',
    'Computer Engineering',
    'Information Technology',
    'Electronics and Telecommunication',
  ];

  var teachers = [
    'Select teacher',
  ];

  var semesters = [
    'Select semester',
  ];

  var classs = [
    'Select class',
  ];

  var subjects = [
    'Select subject',
  ];

  @override
  void initState() {
    super.initState();
    CharacterApi.getTeachers().then((response) {
      setState(() {
        Iterable list = json.decode(response.body);
        teachers.clear();
        selectedTeacher = 'Select teacher';
        teachers.add(selectedTeacher);
        teachers.addAll(list.map((semester) => semester.toString()));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: new AppBar(
        title: new Text("Attend Exam"),
        elevation:defaultTargetPlatform==TargetPlatform.android ? 5.0 : 0.0 ,
      ),
      drawer: new Drawer(
        child: new ListView(
          children: [
            new UserAccountsDrawerHeader(
              accountName: new Text(globalFname),
              accountEmail: new Text(globalHeaderEmail),
              currentAccountPicture: new CircleAvatar(
                backgroundColor:
                Theme.of(context).platform==TargetPlatform. iOS
                    ? Colors.deepPurple
                    :Colors.white,
                child: new Text(globalFname.split(" ")[0][0].toUpperCase()+globalFname.split(" ")[1][0].toUpperCase()),
                // child: new Text("UN"),
              ),
            ),
            new ListTile(
              title: new Text("Attend Exam"),
              trailing: new Icon(Icons.home),
              onTap: (){
                Navigator.of(context).pop();
              },
            ),
            new ListTile(
              title: new Text("Result"),
              trailing: new Icon(Icons.output),
              onTap: (){
                Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>StudentResult()));
              },
            ),
            new ListTile(
                title: new Text("logout"),
                trailing: new Icon(Icons.logout),
                onTap: ()=> Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LoginPage()))
            ),
          ],
        ),
      ),
      body:SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text('Select proper details', style: TextStyle(color: Colors.black, fontSize: 23.0, fontWeight: FontWeight.bold),),
                ],
              ),
              SizedBox(height: 20,),
              TextField(
                controller: userid,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                  labelText: 'Student id',
                  hintText: 'Enter Student id',
                  hintStyle: TextStyle(
                    color: Colors.grey,
                    fontSize: 17.0,
                  ),
                  labelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 17.0,
                    fontWeight: FontWeight.w400,
                  ),
                  prefixIcon: Icon(Iconsax.add1, color: Colors.black, size: 18, ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  floatingLabelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedDepartment,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: departments.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: AutoSizeText(
                      item,
                      maxLines: 2, // Limit to 1 line
                      textAlign: TextAlign.start, // Optional: Text alignment
                      style: TextStyle(fontSize: 17), // Optional: Starting font size
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    CharacterApi.getSem(newValue!).then((response) {
                      setState(() {
                        Iterable list = json.decode(response.body);
                        semesters.clear();
                        classs.clear();
                        subjects.clear();
                        selectedSem = 'Select semester';
                        selectedClass = 'Select class';
                        selectedSubject = 'Select subject';
                        semesters.add('Select semester');
                        classs.add('Select class');
                        subjects.add('Select subject');
                        semesters.addAll(list.map((semester) => semester.toString()));
                      });
                    });
                    selectedDepartment = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedSem,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: semesters.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: AutoSizeText(
                      item,
                      maxLines: 2, // Limit to 1 line
                      textAlign: TextAlign.start, // Optional: Text alignment
                      style: TextStyle(fontSize: 17), // Optional: Starting font size
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    CharacterApi.getClass(selectedDepartment,newValue!).then((response) {
                      setState(() {
                        Iterable list = json.decode(response.body);
                        classs.clear();
                        subjects.clear();
                        selectedClass = 'Select class';
                        selectedSubject = 'Select subject';
                        classs.add('Select class');
                        subjects.add('Select subject');
                        classs.addAll(list.map((semester) => semester.toString()));
                      });
                    });
                    selectedSem = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedClass,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: classs.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: AutoSizeText(
                      item,
                      maxLines: 2, // Limit to 1 line
                      textAlign: TextAlign.start, // Optional: Text alignment
                      style: TextStyle(fontSize: 17), // Optional: Starting font size
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    CharacterApi.getSubject(selectedDepartment,selectedSem,newValue!).then((response) {
                      setState(() {
                        Iterable list = json.decode(response.body);
                        subjects.clear();
                        selectedSubject = 'Select subject';
                        subjects.add('Select subject');
                        subjects.addAll(list.map((semester) => semester.toString()));
                      });
                    });
                    selectedClass = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedSubject,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: subjects.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child:  Container(
                      width: 250, // Adjust this width according to your needs
                      child: AutoSizeText(
                        item,
                        maxLines: 2, // Limit to 1 line
                        textAlign: TextAlign.start, // Optional: Text alignment
                        style: TextStyle(fontSize: 17), // Optional: Starting font size
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    selectedSubject = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              DropdownButtonFormField(
                value: selectedTeacher,
                icon: const Icon(Icons.keyboard_arrow_down),
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black, width: 1.5),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                items: teachers.map((String item) {
                  return DropdownMenuItem(
                    value: item,
                    child: AutoSizeText(
                      item,
                      maxLines: 2, // Limit to 1 line
                      textAlign: TextAlign.start, // Optional: Text alignment
                      style: TextStyle(fontSize: 17), // Optional: Starting font size
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    selectedTeacher = newValue!;
                  });
                },
              ),
              SizedBox(height: 20,),
              MaterialButton(
                onPressed: () async {
                  String text1,text2,text3,text4,text5,text6;

                  text1 = selectedDepartment;
                  text2 = selectedSem;
                  text3 = selectedClass;
                  text4 = selectedSubject;
                  text5 = selectedTeacher;
                  text6 = userid.text;

                  if(text1 == 'Select department' || text2 == 'Select semester' || text3 == 'Select class' || text4 == 'Select subject' || text5 == 'Select teacher' || text6 == '')
                  {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text("Text Field is empty, Please Fill All Data"),
                    ));
                  }
                  else{
                    final url = serverurl+"checkScore";
                    final response = await http.post(Uri.parse(url), body: json.encode({'sname' : globalFname,'email' : globalHeaderEmail,'dept' : text1,'class' : text3,'subject' : text4}));
                    String responseBody = response.body;
                    if(responseBody == "success"){
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Your response is already submited !"),
                      ));
                    }
                    else{
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>MUltiQuestions(text1,text2,text3,text4,text5,text6)));
                    }
                  }
                },
                height: 55,
                color: Colors.deepPurple,
                child: Text("Submit", style: TextStyle(color: Colors.white, fontSize: 16.0),),
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CharacterApi {
  static Future getSem(dept) {
    return http.get(Uri.parse(serverurl+"getAllSem/"+dept));
  }
  static Future getClass(dept,sem) {
    return http.get(Uri.parse(serverurl+"getAllClass/"+dept+"/"+sem));
  }
  static Future getSubject(dept,sem,cla) {
    return http.get(Uri.parse(serverurl+"getAllSubject/"+dept+"/"+sem+"/"+cla));
  }
  static Future getTeachers() {
    return http.get(Uri.parse(serverurl+"getAllTeachers"));
  }
}


import 'dart:convert';
import 'dart:io';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:student_app/server.dart';
import 'Level_Page1.dart';
import 'MCQ.dart';
import 'TeacherResult.dart';
import 'login.dart';
import 'my-globals.dart';

class ViewData extends StatefulWidget {

  final String dept1,classof1;
  ViewData(this.dept1,this.classof1);

  @override
  _ViewData createState() => _ViewData(dept1,classof1);
}

class _ViewData extends State<ViewData> {

  final String dept,classof;
  _ViewData(this.dept,this.classof);

  List<Map<String, dynamic>> data = [];

  @override
  void initState() {
    super.initState();
    CharacterApi.getAllStudentData(trglobalFname,dept,classof).then((response) {
      setState(() {
        Iterable list = json.decode(response.body);
        print("--------------------------------------------");
        print(list.length);
        print("--------------------------------------------");
        for (var item in list) {
          if (item is Map<String, dynamic>) {
            data.add(item);
          }
        }
      });
    });
    // String jsonResponse = '[{"name": "John", "age": 30}, {"name": "Alice", "age": 25}]';
    // // Decoding JSON
    // data = List<Map<String, dynamic>>.from(json.decode(jsonResponse));
  }

  void _onSaveClicked() async {
    // print('Updated Data: $data');
    final url = serverurl+"predictData";
    final response = await http.post(Uri.parse(url), body: json.encode({'data' : data}));

    String responseBody = response.body;

    if(responseBody != "fail"){
      Iterable list = json.decode(response.body);
      Navigator.of(context).push(MaterialPageRoute(builder: (BuildContext context) => TeacherResult(list)));
    }
    else{
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Enter marks for all subjects !"),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: new AppBar(
          title: new Text("Student data"),
          leading: new IconButton(
              icon: new Icon(Icons.arrow_back),
              onPressed: (){
                Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LevelPage1()));
              }
          ),
          elevation:defaultTargetPlatform==TargetPlatform.android ? 5.0 : 0.0 ,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(1.0),
            child: Column(
              children: [
                SizedBox(height: 5,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: <DataColumn>[
                      DataColumn(
                        label: Text('Student Id'),
                      ),
                      DataColumn(
                        label: Text('Student name'),
                      ),
                      DataColumn(
                        label: Text('Department'),
                      ),
                      DataColumn(
                        label: Text('Class'),
                      ),
                      DataColumn(
                        label: Text('Subject'),
                      ),
                      DataColumn(
                        label: Text('Ct1'),
                      ),
                      DataColumn(
                        label: Text('Ct2'),
                      ),
                      DataColumn(
                        label: Text('Viva1'),
                      ),
                      DataColumn(
                        label: Text('Viva2'),
                      ),
                      DataColumn(
                        label: Text('Questionary score'),
                      ),
                    ],
                    rows: List<DataRow>.generate(
                      data.length,
                          (index) => DataRow(
                        cells: <DataCell>[
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['studid'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['studid'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['studentname'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['studentname'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['dept'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['dept'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['class'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['class'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['subject'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['subject'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['ct1'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['ct1'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['ct2'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['ct2'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['viva1'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['viva1'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['viva2'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['viva2'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['quescore'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['quescore'] = value;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 25,),
                MaterialButton(
                  onPressed: () async {
                    _onSaveClicked();
                  },
                  height: 55,
                  color: Colors.deepPurple,
                  child: Text("Calculate score", style: TextStyle(color: Colors.white, fontSize: 16.0),),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}

class CharacterApi {
  static Future getAllStudentData(teacher,dept,classof) {
    return http.get(Uri.parse(serverurl+"getAllStudentData/"+teacher+"/"+dept+"/"+classof));
  }
}


library globals;

String globalFname= "";
String globalHeaderDept= "";
String globalHeaderEmail= "";

String trglobalFname= "";
String trglobalHeaderEmail= "";

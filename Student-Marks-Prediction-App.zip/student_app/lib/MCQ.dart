import 'dart:async';
import 'dart:convert';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:student_app/Level_Page.dart';
import 'package:student_app/server.dart';
import 'my-globals.dart';

class MUltiQuestions extends StatefulWidget {
  final String dept1,sem1,classof1,subject1,teacher1,stuid1;
  MUltiQuestions(this.dept1,this.sem1,this.classof1,this.subject1,this.teacher1,this.stuid1);

  @override
  State<MUltiQuestions> createState() => _MUltiQuestionsState(dept1,sem1,classof1,subject1,teacher1,stuid1);
}

class _MUltiQuestionsState extends State<MUltiQuestions> {
  final String dept,sem,classof,subject,teacher,stuid;
  _MUltiQuestionsState(this.dept,this.sem,this.classof,this.subject,this.teacher,this.stuid);

  Timer? _timer; // Declare timer variable as nullable
  int _remainingTimeInSeconds = 60; // Initial remaining time in seconds

  List characterList = [];
  void getCharactersfromApi() async {
    CharacterApi.getCharacters(dept,sem,classof,subject).then((response) {
      setState(() {
        Iterable list = json.decode(response.body);
        print(list);
        characterList.addAll(list) ;
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getCharactersfromApi();
    // Start the timer when the widget is initialized
    _startTimer();
  }

  int seed = 0;

// Function to start the timer
  void _startTimer() {
    const duration = Duration(seconds: 1); // Set the duration to 1 second
    _timer = Timer.periodic(duration, (timer) {
      setState(() {
        if (_remainingTimeInSeconds > 0) {
          _remainingTimeInSeconds--;
        } else {
          timer.cancel(); // Cancel the timer when time is up
          _handleSubmit(); // Submit the page
        }
      });
    });
  }

  // Function to cancel the timer
  void _cancelTimer() {
    _timer?.cancel(); // Cancel the timer if it's active
  }

  // Function to handle submitting the page
  void _handleSubmit() async {
    _cancelTimer(); // Cancel the timer before submitting
    // Your submission logic here
    final url = serverurl + "submitScore";
    final response = await http.post(Uri.parse(url), body: json.encode({'sname': globalFname, 'email': globalHeaderEmail, 'dept': dept, 'class': classof, 'subject': subject, 'teacher': teacher, 'score': seed, 'stuid': stuid}));
    String responseBody = response.body;
    if (responseBody == "success") {
      showDialog(
        context: context,
        builder: (context) {
          Widget okButton = TextButton(
            child: Text("Ok"),
            onPressed: () async {
              Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => LevelPage()));
            },
          );
          return AlertDialog(
            title: Text("Result"),
            content: Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: "Your response is submitted successfully!"),
                  // TextSpan(text: "Score : $seed / ${characterList.length * 2}", style: TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            actions: [
              okButton,
            ],
          );
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Something is wrong!"),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: new IconButton(
            icon: new Icon(Icons.arrow_back),
            onPressed: () {
              _cancelTimer();
              Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => LevelPage()));
            }),
        title: Row(
          children: [
            Expanded(
              child: Text('Questionary', textAlign: TextAlign.left),
            ),
            Row(
              children: [
                Icon(Icons.timer),
                SizedBox(width: 5),
                Text('$_remainingTimeInSeconds s'),
              ],
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            FloatingActionButton(
              child: Icon(Icons.view_agenda_outlined),
              onPressed: _handleSubmit,
            ),
            FloatingActionButton(
              child: Icon(Icons.refresh),
              onPressed: () {
                setState(() {
                  seed = 0;
                  characterList.forEach((element) {
                    element[0] = null; // Clear selected value
                  });
                });
              },
            ),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: characterList.length,
        itemBuilder: (context, index) {
          return  Card(
            margin: EdgeInsets.symmetric(vertical: 5.0,horizontal: 10.0),
            elevation: 1.5,
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                padding: EdgeInsets.all(20),
                child:
                Column(
                  children: [
                    AutoSizeText(characterList[index][1], style: TextStyle(
                        fontSize: 18
                    ),),

                    Divider(thickness: 1,),

                    RadioListTile(
                      title: Container(
                        width: 200, // Adjust this width according to your needs
                        child: AutoSizeText(
                          characterList[index][2],
                          maxLines: 2, // Limit to 1 line
                          textAlign: TextAlign.start, // Optional: Text alignment
                          style: TextStyle(fontSize: 16), // Optional: Starting font size
                        ),
                      ),
                      value: characterList[index][2].toString(),
                      groupValue: characterList[index][0],
                      onChanged: (value) {
                        setState(() {
                          characterList[index][0]=value.toString();
                          if(characterList[index][6].toString()==value)
                          {
                            seed += 2;
                            // updateScore();
                          }
                        });
                      },
                    ),

                    RadioListTile(
                      title: Container(
                        width: 200, // Adjust this width according to your needs
                        child: AutoSizeText(
                          characterList[index][3],
                          maxLines: 2, // Limit to 1 line
                          textAlign: TextAlign.start, // Optional: Text alignment
                          style: TextStyle(fontSize: 16), // Optional: Starting font size
                        ),
                      ),
                      value: characterList[index][3].toString(),
                      groupValue: characterList[index][0],
                      onChanged: (value) {
                        setState(() {
                          characterList[index][0]=value.toString();
                          if(characterList[index][6].toString()==value)
                          {
                            seed += 2;
                            // updateScore();
                          }
                        });
                      },
                    ),

                    RadioListTile(
                      title: Container(
                        width: 200, // Adjust this width according to your needs
                        child: AutoSizeText(
                          characterList[index][4],
                          maxLines: 2, // Limit to 1 line
                          textAlign: TextAlign.start, // Optional: Text alignment
                          style: TextStyle(fontSize: 16), // Optional: Starting font size
                        ),
                      ),
                      value: characterList[index][4].toString(),
                      groupValue: characterList[index][0],
                      onChanged: (value) {
                        setState(() {
                          characterList[index][0]=value.toString();
                          if(characterList[index][6].toString()==value)
                          {
                            seed += 2;
                            // updateScore();
                          }
                        });
                      },
                    ),

                    RadioListTile(
                      title: Container(
                        width: 200, // Adjust this width according to your needs
                        child: AutoSizeText(
                          characterList[index][5],
                          maxLines: 2, // Limit to 1 line
                          textAlign: TextAlign.start, // Optional: Text alignment
                          style: TextStyle(fontSize: 16), // Optional: Starting font size
                        ),
                      ),
                      value: characterList[index][5].toString(),
                      groupValue: characterList[index][0],
                      onChanged: (value) {
                        setState(() {
                          characterList[index][0]=value.toString();
                          if(characterList[index][6].toString()==value)
                          {
                            seed += 2;
                            // updateScore();
                          }
                        });
                      },
                    ),

                  ],
                ),
              ),
            ),
          );
        },

      ),

    );
  }
}

class CharacterApi {
  static Future getCharacters(dept,sem,classof,subject) {
    return http.get(Uri.parse(serverurl+"getQuestions/"+dept+"/"+sem+"/"+classof+"/"+subject));
  }
}


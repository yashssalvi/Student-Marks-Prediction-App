import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:student_app/server.dart';

import 'login.dart';

class register extends StatefulWidget {
  const register({ Key? key }) : super(key: key);

  @override
  _registerState createState() => _registerState();
}

class _registerState extends State<register> {

  var Fname = TextEditingController();
  var phone = TextEditingController();
  var email = TextEditingController();
  var pass = TextEditingController();
  var Cpass = TextEditingController();

  String dropdownvalue = 'Select department';

  var items = [
    'Select department',
    'Computer Engineering',
    'Information Technology',
    'Electronics and Telecommunication',
  ];
  int activeIndex = 0;

  @override
  void initState() {
    Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        activeIndex++;

        if (activeIndex == 4)
          activeIndex = 0;
      });
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(20.0),
            child: Column(
              children: [
                SizedBox(height: 30,),
                Container(
                  height: 250,
                  child: Stack(
                      children: [
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: AnimatedOpacity(
                            opacity: activeIndex == 0 ? 1 : 0,
                            duration: Duration(seconds: 1,),
                            curve: Curves.linear,
                            child: Image.asset('assets/img/login.png', height: 400,),
                          ),
                        ),
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: AnimatedOpacity(
                            opacity: activeIndex == 1 ? 1 : 0,
                            duration: Duration(seconds: 1),
                            curve: Curves.linear,
                            child: Image.asset('assets/img/signup.png', height: 400,),
                          ),
                        ),
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: AnimatedOpacity(
                            opacity: activeIndex == 2 ? 1 : 0,
                            duration: Duration(seconds: 1),
                            curve: Curves.linear,
                            child: Image.asset('assets/img/ab.png', height: 400,),
                          ),
                        ),
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: AnimatedOpacity(
                            opacity: activeIndex == 3 ? 1 : 0,
                            duration: Duration(seconds: 1),
                            curve: Curves.linear,
                            child: Image.asset('assets/img/bc.png', height: 400,),
                          ),
                        ),
                      ]
                  ),
                ),
                SizedBox(height: 30,),
                TextField(
                  controller: Fname,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                    labelText: 'Full name',
                    hintText: 'Enter full name',
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 17.0,
                    ),
                    prefixIcon: Icon(Iconsax.user, color: Colors.black, size: 18,),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    floatingLabelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                TextField(
                  keyboardType: TextInputType.number,
                  controller: phone,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                    labelText: 'Contact number',
                    hintText: 'Enter contact number',
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 17.0,
                    ),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    prefixIcon: Icon(Iconsax.call, color: Colors.black, size: 18, ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    floatingLabelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                TextField(
                  controller: email,
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                    labelText: 'Email',
                    hintText: 'Enter email id',
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 17.0,
                    ),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    prefixIcon: Icon(Iconsax.card_pos, color: Colors.black, size: 18, ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    floatingLabelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                TextField(
                  controller: pass,
                  obscureText: true, // This will hide the password input
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                    labelText: 'Password',
                    hintText: 'Enter password',
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 17.0,
                    ),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    prefixIcon: Icon(Iconsax.key, color: Colors.black, size: 18, ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    floatingLabelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                TextField(
                  controller: Cpass,
                  obscureText: true, // This will hide the password input
                  cursorColor: Colors.black,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(vertical: 20.0),
                    labelText: 'Confirm Password',
                    hintText: 'Enter confirm password',
                    hintStyle: TextStyle(
                      color: Colors.grey,
                      fontSize: 17.0,
                    ),
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    prefixIcon: Icon(Iconsax.key1, color: Colors.black, size: 18, ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    floatingLabelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
                SizedBox(height: 15,),
                DropdownButtonFormField(
                  value: dropdownvalue,
                  icon: const Icon(Icons.keyboard_arrow_down),
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
                    labelText: 'Select department',
                    labelStyle: TextStyle(
                      color: Colors.black,
                      fontSize: 17.0,
                      fontWeight: FontWeight.w400,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade200, width: 2),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black, width: 1.5),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  items: items.map((String item) {
                    return DropdownMenuItem(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownvalue = newValue!;
                    });
                  },
                ),
                SizedBox(height: 20,),
                MaterialButton(
                  onPressed: () async {
                    String text1,text2,text3,text4,text5,text6;

                    text1 = Fname.text ;
                    text2 = phone.text ;
                    text3 = email.text;
                    text4 = pass.text;
                    text5 = Cpass.text;
                    text6 = dropdownvalue;

                    final RegExp emailValidatorRegExp = RegExp(r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+.com");

                    if(text1 == '' || text2 == '' || text3 == '' || text4 == ''|| text5 == ''|| text6 == 'Select department')
                    {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Text Field is empty, Please Fill All Data"),
                      ));
                    }
                    else if(!emailValidatorRegExp.hasMatch(text3))
                    {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Email must be valid!"),
                      ));
                    }
                    else if(text2.length != 10)
                    {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Mobile number must be valid!"),
                      ));
                    }
                    else if(text4 != text5)
                    {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text("Confirm password should match with password!"),
                      ));
                    }
                    else{
                      //url to send the post request to
                      final url = serverurl+"register";

                      //sending a post request to the url
                      final response = await http.post(Uri.parse(url), body: json.encode({'fname' : text1,'mob' : text2,'email' : text3,'password' : text4,'department' : text6}));

                      String responseBody = response.body;

                      if(responseBody == "success"){
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text("You have been registered !"),
                        ));
                        goToLoginScreen();
                      }
                      else{
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text("Something is wrong !"),
                        ));
                      }
                    }
                  },
                  height: 55,
                  color: Colors.deepPurple,
                  child: Text("Sign Up", style: TextStyle(color: Colors.white, fontSize: 16.0),),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                ),
                SizedBox(height: 5,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Have an account?', style: TextStyle(color: Colors.grey.shade600, fontSize: 18.0, fontWeight: FontWeight.bold),),
                    TextButton(
                      onPressed: () {
                        // Navigator.of(context).pop();
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LoginPage()));
                      },
                      child: Text('Sign In', style: TextStyle(color: Colors.deepPurple, fontSize: 18.0, fontWeight: FontWeight.bold),),
                    )
                  ],
                ),
              ],
            ),
          ),
        )
    );
  }


  void goToLoginScreen() {
    Navigator.pushReplacementNamed(context, "/login");
  }

  void goToRegisterScreen() {
    Navigator.pushReplacementNamed(context, "/register");
  }


}

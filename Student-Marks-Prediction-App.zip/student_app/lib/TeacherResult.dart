import 'dart:convert';
import 'dart:io';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:student_app/server.dart';
import 'Level_Page1.dart';
import 'MCQ.dart';
import 'ViewData.dart';
import 'login.dart';
import 'my-globals.dart';

class TeacherResult extends StatefulWidget {

  final Iterable<dynamic> myList1;
  TeacherResult(this.myList1);

  @override
  _TeacherResult createState() => _TeacherResult(myList1);
}

class _TeacherResult extends State<TeacherResult> {

  final Iterable<dynamic> myList;
  _TeacherResult(this.myList);

  List<Map<String, dynamic>> data = [];

  @override
  void initState() {
    super.initState();
    data = List<Map<String, dynamic>>.from(myList);
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: new AppBar(
          title: new Text("Result"),
          leading: new IconButton(
              icon: new Icon(Icons.arrow_back),
              onPressed: (){
                Navigator.pop(context);
              }
          ),
          elevation:defaultTargetPlatform==TargetPlatform.android ? 5.0 : 0.0 ,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(1.0),
            child: Column(
              children: [
                SizedBox(height: 5,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: <DataColumn>[
                      DataColumn(
                        label: Text('Student Id'),
                      ),
                      DataColumn(
                        label: Text('Student name'),
                      ),
                      DataColumn(
                        label: Text('Class'),
                      ),
                      DataColumn(
                        label: Text('Subject'),
                      ),
                      DataColumn(
                        label: Text('Result'),
                      ),
                    ],
                    rows: List<DataRow>.generate(
                      data.length,
                          (index) => DataRow(
                        cells: <DataCell>[
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['studid'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['studid'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['studentname'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['studentname'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['class'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['class'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['subject'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['subject'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['result'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['result'] = value;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}


import 'dart:convert';
import 'dart:io';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:student_app/server.dart';
import 'Level_Page.dart';
import 'Level_Page1.dart';
import 'MCQ.dart';
import 'ViewData.dart';
import 'login.dart';
import 'my-globals.dart';

class StudentResult extends StatefulWidget {

  @override
  _TeacherResult createState() => _TeacherResult();
}

class _TeacherResult extends State<StudentResult> {

  List<Map<String, dynamic>> data = [];

  @override
  void initState() {
    super.initState();
    CharacterApi.getResult(globalFname,globalHeaderEmail).then((response) {
      setState(() {
        Iterable list = json.decode(response.body);
        print("--------------------------------------------");
        print(list.length);
        print("--------------------------------------------");
        for (var item in list) {
          if (item is Map<String, dynamic>) {
            data.add(item);
          }
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: new AppBar(
          title: new Text("Result"),
          elevation:defaultTargetPlatform==TargetPlatform.android ? 5.0 : 0.0 ,
        ),
        drawer: new Drawer(
          child: new ListView(
            children: [
              new UserAccountsDrawerHeader(
                accountName: new Text(globalFname),
                accountEmail: new Text(globalHeaderEmail),
                currentAccountPicture: new CircleAvatar(
                  backgroundColor:
                  Theme.of(context).platform==TargetPlatform. iOS
                      ? Colors.deepPurple
                      :Colors.white,
                  child: new Text(globalFname.split(" ")[0][0].toUpperCase()+globalFname.split(" ")[1][0].toUpperCase()),
                  // child: new Text("UN"),
                ),
              ),
              new ListTile(
                title: new Text("Attend Exam"),
                trailing: new Icon(Icons.home),
                onTap: (){
                  Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LevelPage()));
                },
              ),
              new ListTile(
                title: new Text("Result"),
                trailing: new Icon(Icons.output),
                onTap: (){
                  Navigator.of(context).pop();
                },
              ),
              new ListTile(
                  title: new Text("logout"),
                  trailing: new Icon(Icons.logout),
                  onTap: ()=> Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context)=>LoginPage()))
              ),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(1.0),
            child: Column(
              children: [
                SizedBox(height: 5,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: <DataColumn>[
                      DataColumn(
                        label: Text('Student Id'),
                      ),
                      DataColumn(
                        label: Text('Class'),
                      ),
                      DataColumn(
                        label: Text('Subject'),
                      ),
                      DataColumn(
                        label: Text('Teacher name'),
                      ),
                      DataColumn(
                        label: Text('Result'),
                      ),
                    ],
                    rows: List<DataRow>.generate(
                      data.length,
                          (index) => DataRow(
                        cells: <DataCell>[
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['studid'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['studid'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['class'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['class'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['subject'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['subject'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['teacher'].toString(),
                              onChanged: (value) {
                                setState(() {
                                  data[index]['teacher'] = value;
                                });
                              },
                            ),
                          ),
                          DataCell(
                            TextFormField(
                              initialValue: data[index]['result'].toString(),
                              keyboardType: TextInputType.number,
                              onChanged: (value) {
                                setState(() {
                                  data[index]['result'] = value;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
    );
  }
}

class CharacterApi {
  static Future getResult(name,email) {
    return http.get(Uri.parse(serverurl+"getStudentResult/"+name+"/"+email));
  }
}

